  <!-- bottom-page -->
  <div class="bottom-page">
      <div class="body-text">Copyright © <?php echo e(date("Y")); ?> <?php echo e(env('APP_NAME')); ?>. Developed With</div>
      <i class="icon-heart"></i>
      <div class="body-text">by <a target="_blank" href="https://guddu-kumar5.github.io">Guddu Kumar</a> All rights reserved.</div>
  </div>
  <!-- /bottom-page --><?php /**PATH D:\guddu\xampp\htdocs\summit\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>