    <!-- Javascript -->
    <script src="{{url('public/admin/assets')}}/js/jquery.min.js"></script>
    <script src="{{url('public/admin/assets')}}/js/bootstrap.min.js"></script>
    <script src="{{url('public/admin/assets')}}/js/bootstrap-select.min.js"></script>
    <script src="{{url('public/admin/assets')}}/js/zoom.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/apexcharts.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-1.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-2.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-3.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-4.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-5.js"></script>
    <script src="{{url('public/admin/assets')}}/js/apexcharts/line-chart-6.js"></script>
    <script src="{{url('public/admin/assets')}}/js/switcher.js"></script>
    <script src="{{url('public/admin/assets')}}/js/theme-settings.js"></script>
    <script src="{{url('public/admin/assets')}}/js/main.js"></script>