<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return Product::with('category', 'variants.attributes.attribute')->paginate(10);
    }

    // public function show($slug)
    // {
    //     return Product::with('category','variants.images', 'variants.attributes.attribute','related')
    //         ->where('slug', $slug)
    //         ->firstOrFail();
    // }

    public function show($slug)
    {
        $product = Product::with([
            'category',
            'variants.images',
            'variants.attributes.attribute',
        ])->where('slug', $slug)->firstOrFail();

        $product->related = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->with(['variants.images','variants.attributes.attribute'])
            ->take(4)
            ->get();

        return response()->json($product);
    }


    public function store(Request $request)
    {
        $product = Product::create($request->only([
            'name',
            'slug',
            'category_id',
            'description',
            'short_description',
            'meta_title',
            'meta_description'
        ]));

        return response()->json($product, 201);
    }
}
