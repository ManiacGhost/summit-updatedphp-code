<?php 


return [

    'paths' => ['api/*'],

    'allowed_methods' => ['*'],

    // 👇 Replace with your frontend’s actual origin
    'allowed_origins' => ['http://localhost:5173', 'http://127.0.0.1:5173'],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    // 👇 Must be true if you’re sending cookies or session data
    'supports_credentials' => true,

];
